import SwiftUI


@main
struct MyApp: App {
    @State private var showSplashScreen : Bool = true;
    var body: some Scene {
        WindowGroup {
            if showSplashScreen{
                Image("AlvatixLogo").resizable()
                    .frame(width: 300, height: 70)
                    .onAppear {
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            withAnimation (Animation.easeInOut(duration: 1.0).repeatForever()) {
                               
                                showSplashScreen = false
                            }
                        }
                    }
            }
           else{
               ContentView()
           }
        }
    }
}

