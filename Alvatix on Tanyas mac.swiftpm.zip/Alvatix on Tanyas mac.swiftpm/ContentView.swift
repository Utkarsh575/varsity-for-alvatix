import SwiftUI

struct Card: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let url : String?
    let image : String
}

struct ContentView: View {
    let cards: [Card] = [
        Card(title: "Types of Tokens", description: "Cryptocurrencies come in various types", url:"", image: ""),
        Card(title: "Types of Traders", description: "Low Risk low reward vs High risk high reward", url:"" ,image: ""),
        Card(title: "How to identify Good trades?", description: "Metrics used by Alvatix", url:"" , image:"")
    ]
    
    @State public var currentIndex = 2
    
    var body: some View {
        VStack{
            Text("Varsity by Alvatix").foregroundColor(.white).font(.largeTitle).bold().padding(.top , 5)
            
            GeometryReader { geometry in
                
                ZStack {
                    ForEach(cards.indices) { index in
                        CardView(card: cards[index] , currentIndex : index)
                            .offset(x: CGFloat(index - currentIndex) * geometry.size.width)
                            .gesture(
                                DragGesture()
                                    .onEnded { value in
                                        withAnimation {
                                            if value.translation.width < -50 && currentIndex < cards.count - 1 {
                                                currentIndex += 1
                                            } else if value.translation.width > 50 && currentIndex > 0 {
                                                currentIndex -= 1
                                            }
                                        }
                                    }
                            )
                    }
                }
            }
            ProgressView(value: Float(currentIndex)/5+0.1)
            
        }.background(Image("Group 1-2"))
        
    }
    
}




struct CardView: View {
    let card: Card
    let currentIndex : Int
    var body: some View {
        
        RoundedRectangle(cornerRadius: 25)
            .fill(Color.black).shadow(radius: 10)
        //            .background(Image("Group 1").resizable())
            .frame(width: .infinity, height: .infinity)
            .overlay(
                VStack {
                    Text(card.title)
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 20)
                    
                    
                    
                    Image(card.image)
                    VStack{
                        Text(card.description)
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding().font(.headline)
                        
                        if(currentIndex==0){
                            Text("* **Currency🤑** :  Like Bitcoin and Litecoin, designed primarily as digital currencies for peer-to-peer transactions and store of value.\n\n * **Platform Tokens🎟️** : Such as Ethereum's Ether, utilized to fuel decentralized applications (dApps) and execute smart contracts on their respective platforms. \n\n * **Stablecoins🏦** : Pegged to stable assets like fiat currencies, providing stability and facilitating seamless transactions in the volatile cryptocurrency market \n\n * **Utility Tokens🎫** : Offered by blockchain projects for accessing specific services or products within their ecosystems, like Binance Coin for reduced trading fees. \n\n * **Meme Coins🤡** Like Dogecoin and Shiba Inu, originally started as internet jokes, now traded for speculative purposes and community engagement." as LocalizedStringKey).multilineTextAlignment(.leading).padding().font(.callout)
                            Image("crypto-confused").resizable().frame(width: 430 , height: 270).cornerRadius(10)
                            Spacer()
                            
                        }
                        if(currentIndex==1){
                            Text("* **Long term trader** : Adhere to the `HODL` strategy prioritize capital preservation over maximizing returns. They favor established cryptocurrencies like Bitcoin and Ethereum for their stability and widespread adoption. By employing strategies such as dollar-cost averaging and long-term holding, they aim for steady, albeit modest gains. While this approach may bypass the potential for quick, high returns seen in speculative investments, HODLers prioritize stability and consistency in their investment portfolios. This conservative mindset ensures resilience against market volatility and aligns with their goal of long-term wealth preservation. \n\n    * **Short term traders** :  The thrill-seekers, chasing the adrenaline rush of potentially massive gains. They gravitate towards volatile assets and speculative cryptocurrencies, eager to capitalize on price fluctuations. With a penchant for risk-taking, they deploy aggressive trading strategies like day trading and leveraged trading, aiming for quick profits. These traders thrive on market volatility, often embracing the mantra `go big or go home.` While their approach carries significant risks of losses, they are driven by the allure of substantial returns, making each trade an exhilarating gamble in pursuit of financial fortune." as LocalizedStringKey).multilineTextAlignment(.leading).padding().font(.callout)
                            
                            Image("hodl-meme").resizable().frame(width: 350 ,height: 230).cornerRadius(10)
                            
                            
                            
                            
                        }
                        if(currentIndex==2){
                            Text("* **OnChain⛓** : provide insights into cryptocurrency trading by analyzing blockchain data, aiding in understanding market trends and investor behavior. \n\n * **Whale Flow🐳** : Whale flow analysis provides crucial insights into large-scale cryptocurrency transactions, influencing market sentiment and trading decisions. \n\n * **Social Sentiment👥** : Social sentiment analysis gauges public perception of cryptocurrencies, impacting market sentiment and influencing trading decisions. \n\n * **Delta C𝝙P** : Delta Cap analysis helps identify extremes in Bitcoin market cycles, informing traders about potential turning points and guiding trading strategies. \n\n * **Exchange Flow💱** : Exchange flow monitoring tracks the movement of cryptocurrencies into and out of exchanges, providing valuable insights into investor behavior and market liquidity, influencing trading decisions. \n\n * **Technical Analysis🧐** : It utilizes price trends and patterns to inform crypto traders' decisions, influencing their choice of entry and exit points in the market." as LocalizedStringKey).multilineTextAlignment(.leading).padding().font(.callout)
                            
                            Image("metrics").resizable().frame(width: 450 ,height: 100).cornerRadius(10)
                            
                        }
                        
                    }
                    
                    
                }.frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/ , maxHeight: .infinity , alignment: .top)
            ).padding(.horizontal,40).padding(.bottom , 30)
        
    }
}


