import SwiftUI


struct TopicView: View {
    @State public var currentIndex = 1;


    var body: some View {
        VStack{
            
        
            Text("Topics").foregroundColor(.white)
//            HStack{
//                ForEach(0..<7) { _ in
//                    RoundedRectangle(cornerRadius: 5)
//                        .fill(Color.blue)
//                        .frame(width: 150, height: 200)
//                        .padding(10)
            //                }
//            }
            
            VStack(spacing: 10) {
                HStack(spacing:2){
                    
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.green)
                        .frame(width: 230, height: 200)
                        .padding(10)
                        .overlay { 
                            VStack{
                                Text("Crypto currency Basics").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).bold()
                                Text("01").font(.subheadline).italic().padding(.leading,170).padding(.top,75)

                            }           
                        }
                    
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.blue)
                        .frame(width: 230, height: 200)
                        .padding(10)
                }
                
                HStack(spacing:2){
                    
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.blue)
                        .frame(width: 230, height: 200)
                        .padding(10)
                        .overlay { 
                            Text("meow")
                        }
                    
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.blue)
                        .frame(width: 230, height: 200)
                        .padding(10)
                }

                }

                
            
            
            
            
        
            
        }.frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/ , maxHeight: .infinity , alignment: .top).background(.black)

    }

    
}

